<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLocationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('locations', function (Blueprint $table) {
            $table->increments('id');
            $table->string('postcode');
            $table->string('open_Monday');
            $table->string('open_Tuesday');
            $table->string('open_Wednesday');
            $table->string('open_Thursday');
            $table->string('open_Friday');
            $table->string('open_Saturday');
            $table->string('open_Sunday');
            $table->string('closed_Monday');
            $table->string('closed_Wednesday');
            $table->string('closed_Tuesday');
            $table->string('closed_Thursday');
            $table->string('closed_Friday');
            $table->string('closed_Saturday');
            $table->string('closed_Sunday');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('locations');
    }
}
