<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/submitpods', function () {

    $pod_type = array('Ristretto', 'Espresso', 'Lungo');
    return view('form') -> with('pod_type', $pod_type);
});

Route::get('/submitlocation', function () {
    return view('locationform');
});
