<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

//List all locations
Route::get('locations', 'LocationController@index');

//List a single location
Route::get('location/{id}', 'LocationController@show');

//Create a new location
Route::post('location', 'LocationController@store');

//Update location
Route::put('location', 'LocationController@store');

//Delete a location
Route::delete('location/{id}', 'LocationController@destroy');



//List all pod trades
Route::get('pods', 'PodController@index');

//List a single location
Route::get('pod/{id}', 'PodController@show');

//Create a new location
Route::post('pod', 'PodController@store');

//Update location
Route::put('pod', 'PodController@store');

//Delete a location
Route::delete('pod/{id}', 'podController@destroy');
