<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <body>
      <?php echo e(Form::open(array('url' => '/api/pod/', 'method' => 'POST'))); ?>

        <!-- <div>ID: <?php echo e(Form::number('id')); ?><div> -->
        <!-- <div>Pod Size: <?php echo e(Form::select('pod_type', $pod_type)); ?></div>-> -->
        <div>Pod Type: <?php echo e(Form::text('pod_type')); ?></div>
        <br>
        <div>Quantity: <?php echo e(Form::number('quantity')); ?><div>
        <br>
        <div>Location: <?php echo e(Form::text('location', 'Enter Postcode')); ?></div>
        <br>
        <?php echo e(Form::submit('Submit')); ?>

      <?php echo e(Form::close()); ?>

    </body>
</html>
