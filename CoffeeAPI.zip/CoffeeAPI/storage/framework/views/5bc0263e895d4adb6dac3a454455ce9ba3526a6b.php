<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <body>
      <?php echo e(Form::open(array('url' => '/api/location/', 'method' => 'POST'))); ?>


        <div>Location Postcode: <?php echo e(Form::text('postcode')); ?></div>
        <br>
        <div>open_Monday: <?php echo e(Form::text('open_Monday')); ?></div>
        <br>
        <div>open_Tuesday: <?php echo e(Form::text('open_Tuesday')); ?></div>
        <br>
        <div>open_Wednesday: <?php echo e(Form::text('open_Wednesday')); ?></div>
        <br>
        <div>open_Thursday: <?php echo e(Form::text('open_Thursday')); ?></div>
        <br>
        <div>open_Friday: <?php echo e(Form::text('open_Friday')); ?></div>
        <br>
        <div>open_Saturday: <?php echo e(Form::text('open_Saturday')); ?></div>
        <br>
        <div>open_Sunday: <?php echo e(Form::text('open_Sunday')); ?></div>
        <br>
        <div>closed_Monday: <?php echo e(Form::text('closed_Monday')); ?></div>
        <br>
        <div>closed_Wednesday: <?php echo e(Form::text('closed_Wednesday')); ?></div>
        <br>
        <div>closed_Tuesday: <?php echo e(Form::text('closed_Tuesday')); ?></div>
        <br>
        <div>closed_Thursday: <?php echo e(Form::text('closed_Thursday')); ?></div>
        <br>
        <div>closed_Friday: <?php echo e(Form::text('closed_Friday')); ?></div>
        <br>
        <div>closed_Saturday: <?php echo e(Form::text('closed_Saturday')); ?></div>
        <br>
        <div>closed_Sunday: <?php echo e(Form::text('closed_Sunday')); ?></div>
        <br>
        <?php echo e(Form::submit('Submit')); ?>


      <?php echo e(Form::close()); ?>

    </body>
</html>
