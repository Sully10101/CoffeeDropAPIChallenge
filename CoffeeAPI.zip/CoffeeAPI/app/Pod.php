<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pod extends Model
{
  public $timestamps = false;

}
