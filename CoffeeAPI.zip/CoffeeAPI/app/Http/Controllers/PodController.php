<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Pod;
use App\Http\Resources\Pod as PodResource;

class PodController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      //get pod purchases
      $pod = Pod::paginate(50);

      //return collection of purchases as resource
      return PodResource::collection($pod);


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      //If 'put' request, it will require a Pod ID field
      $pod = $request->isMethod('put') ? Pod::findOrFail($request->pod_id) : new Pod;

      $pod->id = $request->input('pod_id');
      $pod->pod_type = $request->input('pod_type');
      $pod->quantity = $request->input('quantity');
      $pod->location = $request->input('location');


      if($pod->save()){
        return new PodResource($pod);
      }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      //Get a single pod purchase
      $pod = Pod::findOrFail($id);

      //Return the single location as a resource
      return new PodResource($pod);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      //Get a single pod purchases
      $pod = Pod::findOrFail($id);

      if($pod->delete()){
        return new PodResource($pod);
      }
    }
}
