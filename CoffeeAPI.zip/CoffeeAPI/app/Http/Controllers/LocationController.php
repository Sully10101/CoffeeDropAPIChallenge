<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Location;
use App\Http\Resources\Location as LocationResource;

class LocationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //get locations
        $locations = Location::paginate(50);

        //return collection of locations as resource
        return LocationResource::collection($locations);


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //If 'put' request, it will require a Location ID field
        $location = $request->isMethod('put') ? Location::findOrFail($request->location_id) : new Location;

        $location->id = $request->input('location_id');
        $location->postcode = $request->input('postcode');
        $location->open_Monday = $request->input('open_Monday');
        $location->open_Tuesday = $request->input('open_Tuesday');
        $location->open_Wednesday = $request->input('open_Wednesday');
        $location->open_Thursday = $request->input('open_Thursday');
        $location->open_Friday = $request->input('open_Friday');
        $location->open_Saturday = $request->input('open_Saturday');
        $location->open_Sunday = $request->input('open_Sunday');
        $location->closed_Monday = $request->input('closed_Monday');
        $location->closed_Wednesday = $request->input('closed_Wednesday');
        $location->closed_Tuesday = $request->input('closed_Tuesday');
        $location->closed_Thursday = $request->input('closed_Thursday');
        $location->closed_Friday = $request->input('closed_Friday');
        $location->closed_Saturday = $request->input('closed_Saturday');
        $location->closed_Sunday = $request->input('closed_Sunday');

        if($location->save()){
          return new LocationResource($location);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //Get a single locations
        $location = Location::findOrFail($id);

        //Return the single location as a resource
        return new LocationResource($location);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Get a single locations
        $location = Location::findOrFail($id);

        if($location->delete()){
          return new LocationResource($location);
        }
    }
}
