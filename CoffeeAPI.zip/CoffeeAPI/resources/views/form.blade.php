<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <body>
      {{ Form::open(array('url' => '/api/pod/', 'method' => 'POST')) }}
        <!-- <div>ID: {{ Form::number('id') }}<div> -->
        <!-- <div>Pod Size: {{ Form::select('pod_type', $pod_type) }}</div>-> -->
        <div>Pod Type: {{ Form::text('pod_type') }}</div>
        <br>
        <div>Quantity: {{ Form::number('quantity') }}<div>
        <br>
        <div>Location: {{ Form::text('location', 'Enter Postcode') }}</div>
        <br>
        {{ Form::submit('Submit') }}
      {{ Form::close() }}
    </body>
</html>
