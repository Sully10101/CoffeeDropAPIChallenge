<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <body>
      {{ Form::open(array('url' => '/api/location/', 'method' => 'POST')) }}

        <div>Location Postcode: {{ Form::text('postcode') }}</div>
        <br>
        <div>open_Monday: {{ Form::text('open_Monday') }}</div>
        <br>
        <div>open_Tuesday: {{ Form::text('open_Tuesday') }}</div>
        <br>
        <div>open_Wednesday: {{ Form::text('open_Wednesday') }}</div>
        <br>
        <div>open_Thursday: {{ Form::text('open_Thursday') }}</div>
        <br>
        <div>open_Friday: {{ Form::text('open_Friday') }}</div>
        <br>
        <div>open_Saturday: {{ Form::text('open_Saturday') }}</div>
        <br>
        <div>open_Sunday: {{ Form::text('open_Sunday') }}</div>
        <br>
        <div>closed_Monday: {{ Form::text('closed_Monday') }}</div>
        <br>
        <div>closed_Wednesday: {{ Form::text('closed_Wednesday') }}</div>
        <br>
        <div>closed_Tuesday: {{ Form::text('closed_Tuesday') }}</div>
        <br>
        <div>closed_Thursday: {{ Form::text('closed_Thursday') }}</div>
        <br>
        <div>closed_Friday: {{ Form::text('closed_Friday') }}</div>
        <br>
        <div>closed_Saturday: {{ Form::text('closed_Saturday') }}</div>
        <br>
        <div>closed_Sunday: {{ Form::text('closed_Sunday') }}</div>
        <br>
        {{ Form::submit('Submit') }}

      {{ Form::close() }}
    </body>
</html>
